@echo off
cd /d "%~dp0"
echo Open http://127.0.0.1:8001/demo_fallback/ after the server starts.
python scripts\serve_demo.py --port 8001
pause
